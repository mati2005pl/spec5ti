
    </div>

    <div class="footer l-box is-center">
		<p>
		<?php out($page_footer); if (!isset($page_footer)) {  ?> Domyślna zawartość stopki ... <?php } ?>
		</p>
        <p>Widok oparty na stylach i szablonie <a href="http://purecss.io/" target="_blank">Pure CSS Yahoo!</a>. (autor przykładu: Przemysław Kudłacik)</p>
	</div>

</div>


</body>
</html>
